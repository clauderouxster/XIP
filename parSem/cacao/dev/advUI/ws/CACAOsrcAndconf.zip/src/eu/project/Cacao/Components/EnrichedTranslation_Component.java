package eu.project.Cacao.Components;


/**
 * This class accesses the manually added translations or the ones inferred by analyzing user logs
 * -Not useful for tel@CLEF
 *
 * @author Alessio
 *
 */
public class EnrichedTranslation_Component {
    public String getManuallyCodedTranslation(String term, String langFROM,
        String langTO) {
        return null;
    }

    public String getLogsBasedTranslation(String term, String langFROM,
        String langTO) {
        return null;
    }
}

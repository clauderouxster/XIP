package eu.project.Cacao.Components;


/**
 * This is an utility class for the navigation of classification hierarchy
 * @author Alessio
 *
 */
public class ClassificationExplorer_Component {
    public ClassificationExplorer_Component() {
        //loads the classification categories from a DB or a file...
    }

    public String[] getTopLevelCategories(int classificationSystemID) {
        return null;
    }

    public String[] getParents(String categoryID) {
        return null;
    }

    public String[] getChildren(String[] categoryID) {
        return null;
    }

    public String[] getCategoryLabels(String categoryID) {
        return null;
    }
}

/* $Id: version.h,v 1.1 2005/02/11 17:40:01 grondeau Exp $ */
/* Copyright (c) 2000 by the Xerox Corporation.  All rights reserved.
   Copyright protection claimed includes all forms and matters of
   copyrightable material and information now allowed by statutory or
   judicial law or hereinafter granted, including without limitation,
   material generated from the software programs which are displayed 
   on the screen such as icons, screen display looks, etc.
   */
/*
 * Description: Version and Revision definitions for NTM, a utility
   for non-deterministic tokenization and morphological analysis
 */

#ifndef NTM_VERSION_H
#define NTM_VERSION_H

#define NTM_VERSION      1
#define NTM_REVISION     1
#define NTM_UPDATE_LEVEL 2
#define NTM_Version      ((NTM_VERSION * 100 + NTM_REVISION) * 100 + NTM_UPDATE_LEVEL)
#define NTM_VERSION_STRING "1.1.2"

#endif /* NTM_VERSION_H */


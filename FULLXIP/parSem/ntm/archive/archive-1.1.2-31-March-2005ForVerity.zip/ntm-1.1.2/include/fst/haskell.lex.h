/* Copyright (c) 1997 by Xerox Research Centre.  All rights reserved. */
/* Created by Tamas Gaal */
/* $Id: haskell.lex.h,v 1.4 2005/03/04 15:45:23 grondeau Exp $ */

void haskell_total_restart();

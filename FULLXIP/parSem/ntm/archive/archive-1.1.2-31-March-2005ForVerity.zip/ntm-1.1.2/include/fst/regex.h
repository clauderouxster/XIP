/* Copyright (c) 1994 by Rank Xerox Research Centre.  All rights reserved. */
/* Created by Pasi Tapanainen. */
/* $Id: regex.h,v 1.4 2005/03/04 15:45:25 grondeau Exp $ */

int regex_parse(void *);
NETptr last_regex(void);

/* void restore_buffer(void);
  void push_buffer(void *, char *);
  */

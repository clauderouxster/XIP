/* $Id: remove_epsilon.h,v 1.4 2005/03/04 15:45:25 grondeau Exp $ */
/* Copyright (c) 1998 by the Xerox Corporation.  All rights reserved */

void FstCalcExport remove_epsilon (NETptr net);

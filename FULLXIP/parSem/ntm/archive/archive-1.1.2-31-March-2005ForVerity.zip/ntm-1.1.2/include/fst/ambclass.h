/* Copyright (c) 1997 by Xerox Research Centre Europe.  All rights reserved. */
/* Created by Lauri Karttunen. */
/* $Id: ambclass.h,v 1.4 2005/03/04 15:45:21 grondeau Exp $ */

NETptr FstCalcExport ambiguity_net(NETptr net, int copy_p, int minimize_p);
NETptr FstCalcExport iy_stringify(NETptr, int, int);

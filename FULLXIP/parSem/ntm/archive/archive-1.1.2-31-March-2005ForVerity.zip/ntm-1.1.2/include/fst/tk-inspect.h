/* $Id: tk-inspect.h,v 1.4 2005/03/04 15:45:26 grondeau Exp $ */
/* (c) 2001 by the Xerox Corporation.  All rights reserved */

void tk_inspect_net(NETptr net);
void tk_inspect_state(STATEptr state);
void tk_inspect_alph(STATEptr alph);

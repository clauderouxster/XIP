/* Copyright (c) 1997 by Rank Xerox Research Centre.  All rights reserved. */
/* Created by Lauri Karttunen. */
/* $Id: fst-prompt.h,v 1.4 2005/03/04 15:45:23 grondeau Exp $ */



#ifndef FST_PROMPT_H
#define FST_PROMPT_H

#ifdef __cplusplus
extern "C" {
#endif

extern char FstCalcExport *FST_PROMPT;


#ifdef __cplusplus
}
#endif
    
#endif /* FST_PROMPT_H */

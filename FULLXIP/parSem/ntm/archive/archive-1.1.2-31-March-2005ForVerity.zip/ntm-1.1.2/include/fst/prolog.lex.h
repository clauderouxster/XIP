/* Copyright (c) 1997 by Xerox Research Centre.  All rights reserved. */
/* Created by Tamas Gaal */
/* $Id: prolog.lex.h,v 1.4 2005/03/04 15:45:25 grondeau Exp $ */

void prolog_total_restart();
int prolog_lex(void);
int prolog_error(char *str);

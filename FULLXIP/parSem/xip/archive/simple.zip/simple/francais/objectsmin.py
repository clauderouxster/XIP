"""
python:

transfert($1,#1,#2,python echange).

"""


def transfert(d,par1,par2,echange):
    dep=XipDependency(d)
    print dep

    

"""
Python:

addsentences(string st,python res).
"""

def addsentences(st,res):
    res.append(st)
    return 1

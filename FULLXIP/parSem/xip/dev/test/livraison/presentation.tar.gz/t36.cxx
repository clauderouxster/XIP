function test(int i,int j) {
   println(i,j);
}

int j;
int i with test;

i=10;

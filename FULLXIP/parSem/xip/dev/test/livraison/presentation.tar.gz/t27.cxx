string s="toto too tt titi";
vector v;
v= "o" in s;
println(v);

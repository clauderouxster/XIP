int i="2"+"3"+5;		// i= 2+3+5=10
println(i);
i=("2"+"3")+5;		//i= (�23�)+5=28
println(i);
string s="MY "+(10+2);	//s=�MY 12�
println(s);

s="MY "+10+2; //s=�MY 102�
println(s);
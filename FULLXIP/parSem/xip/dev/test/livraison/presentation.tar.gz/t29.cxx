string s="ceci [a,b,c,d] est bien";

string x=s['[':']'];
println(x);

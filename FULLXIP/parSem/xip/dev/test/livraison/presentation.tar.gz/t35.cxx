string x="1";
vector vv=["a","b","c","d"];
string s=vv[x.int()-1];
println(s);
pause(10);

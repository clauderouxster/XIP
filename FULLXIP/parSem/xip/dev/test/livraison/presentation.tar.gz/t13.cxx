bool toto=false;
toto=#(toto);
println(toto);

string s="123456789";

s=s.insert(4,"jkjkk");
println(s);

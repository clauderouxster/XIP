if ("aa" in ["bb","cc","dd","aa"])
	println("Ok");

if ("aa" in ["bb","cc","dd","aaa"])
	println("pas Ok");
else
	println("ok");

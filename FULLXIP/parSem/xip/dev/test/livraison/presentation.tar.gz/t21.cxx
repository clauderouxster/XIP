use(_args[0],"TOTO",'c:\XIP\Debug\kifltk.dll');
use("WINDOWS",'c:\XIP\Debug\kifltk.dll');

println("ICI");

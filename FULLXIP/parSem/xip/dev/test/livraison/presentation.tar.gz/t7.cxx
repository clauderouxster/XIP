int i,j;

for (i=0;i<10;i++)
	println(i);

//Multiple initializations and multiple incrementations.
for (i=10,j=100;i>5;i--,j++)
	println(i,j);

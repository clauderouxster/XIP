vector v=["+ab","+acd","+eg"];
string s="acd";
int j=10;
j+="+"+s in v;
if ("+"+s in v)
	println("Ok",j);


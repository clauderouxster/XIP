vector v;
v.push(10);

string s;

s.getstd(true);

println("ICI");
println("La");

s.getstd(false);

println(s);


#include "XipCLIWrapper.h"
#include "xipstlres.h"
#include <windows.h>
#include <vcclr.h>
#include "StringConvertor.h"

#define XML_NONE 0
#define XML_OUTPUT 1
#define XML_INSERT 2


namespace cliWrapper {
	CliWrapperXip::CliWrapperXip()
	{
	}

	CliWrapperXip::~CliWrapperXip()
	{
	}

	CliWrapperXip::!CliWrapperXip()
	{
	}

	int CliWrapperXip::LoadGrammar(System::String^ grmfile) {
		return CliWrapperXip::LoadGrammar(grmfile, '1', XML_NONE);
	}

	int CliWrapperXip::LoadGrammar(System::String^ grmfile, char loadAll) {
		return CliWrapperXip::LoadGrammar(grmfile, loadAll, XML_NONE);
	}

	int CliWrapperXip::LoadGrammar(System::String^ grmfile, char loadAll, int xml) {
		try {
			StringUtilities::StringConvertor sc1(grmfile);
			
			return XipGrmFile(sc1.STLAnsiString.c_str(), loadAll, xml);
		} catch (System::Exception^ err) {
			System::Console::Error->WriteLine("LoadGrammar System::Exception : " + err->Message);
			throw err;
		}

		return -1;
	}

	System::String^ CliWrapperXip::ParseString(System::String^ text, int grmHandler) {
		return CliWrapperXip::ParseString(text, grmHandler, XML_NONE);
	}

	System::String^ CliWrapperXip::ParseString(System::String^ text, int grmHandler, char xmloutput) {
		try {
			StringUtilities::StringConvertor sc1(text);
			std::ostringstream os;

			int res = XipParseStringOS(sc1.STLAnsiString.c_str(), grmHandler, &os, xmloutput);
			if (res == 0) {
				StringUtilities::StringConvertor sc2(os.str());

				return sc2.ToString();
			}
		} catch (System::Exception^ err) {
			System::Console::Error->WriteLine("ParseString System::Exception : " + err->Message);
			throw err;
		}

		return nullptr;
	}

	System::String^ CliWrapperXip::ParseFile(System::String^ file, int grmHandler) {
		return CliWrapperXip::ParseFile(file, grmHandler, XML_NONE);
	}

	System::String^ CliWrapperXip::ParseFile(System::String^ file, int grmHandler, char xmloutput) {
		try {
			StringUtilities::StringConvertor sc1(file);
			std::ostringstream os;

			int res = XipParseFileOS(sc1.STLAnsiString.c_str(), grmHandler, &os, xmloutput);
			if (res == 0) {
				StringUtilities::StringConvertor sc2(os.str());

				return sc2.ToString();
			}
		} catch (System::Exception^ err) {
			System::Console::Error->WriteLine("ParseFile System::Exception : " + err->Message);
			throw err;
		}

		return nullptr;
	}

	void CliWrapperXip::ParseFileToFile(System::String^ file, int grmHandler) {
		CliWrapperXip::ParseFileToFile(file, grmHandler, XML_NONE);
	}

	void CliWrapperXip::ParseFileToFile(System::String^ file, int grmHandler, char xmloutput) {
		try {
			//std::string outExt(".out");
			StringUtilities::StringConvertor sc1(file);
			StringUtilities::StringConvertor out(file + ".out");
			//std::string outFile = sc1.STLAnsiString + outExt;

			//std::ofstream ofs(outFile.c_str());
			std::ofstream ofs(out.STLAnsiString.c_str());
			
			int res = XipParseFileToFile(sc1.STLAnsiString.c_str(), grmHandler, &ofs, xmloutput);		
			/*if (res == 0) {
				std::ifstream fichier(out.STLAnsiString.c_str());
				std::stringstream buffer;
				buffer << fichier.rdbuf();

				//std::cout << "Taille du buffer : " << buffer.str().size() << '\n';
				//std::cout << "buffer content : " << buffer.str() << '\n';
				
				StringUtilities::StringConvertor scb(buffer.str());
				System::String^ ret_ = scb.ToString();

				return ret_;
			}*/
		} catch (System::Exception^ err) {
			System::Console::Error->WriteLine("ParseFileToFile System::Exception : " + err->Message);
			throw err;
		}
	}

	// XML input
	System::String^ CliWrapperXip::ParseXMLString(System::String^ text, int grmHandler, int depth) {
		return CliWrapperXip::ParseXMLString(text, grmHandler, depth, XML_NONE);
	}

	System::String^ CliWrapperXip::ParseXMLString(System::String^ text, int grmHandler, int depth, char xmloutput) {
		try {
			StringUtilities::StringConvertor sc1(text);
			std::ostringstream os;

			//System::Console::WriteLine("before XipParseStringXMLOS " + text + "-" + grmHandler + "-" + depth + "-" + xmloutput);
			int res = XipParseStringXMLOS(sc1.STLAnsiString.c_str(), grmHandler, &os, depth, xmloutput);
			//System::Console::WriteLine("res " + res);
			if (res == 0) {
				StringUtilities::StringConvertor sc2(os.str());

				return sc2.ToString();
			}
		} catch (System::Exception^ err) {
			System::Console::Error->WriteLine("ParseXMLString System::Exception : " + err->Message);
			throw err;
		}

		return nullptr;
	}

	System::String^ CliWrapperXip::ParseXMLFile(System::String^ file, int grmHandler, int depth) {
		return CliWrapperXip::ParseXMLFile(file, grmHandler, depth, XML_NONE);
	}

	System::String^ CliWrapperXip::ParseXMLFile(System::String^ file, int grmHandler, int depth, char xmloutput) {
		try {
			//System::Console::Error->WriteLine("ParseXMLFile");
			
			StringUtilities::StringConvertor sc1(file);
			std::ostringstream os;

			int res = XipParseFileXMLOS(sc1.STLAnsiString.c_str(), grmHandler, &os, depth, xmloutput);
			//System::Console::Error->WriteLine("after XipParseFileXMLOS " + res);
			if (res == 0) {
				StringUtilities::StringConvertor sc2(os.str());

				return sc2.ToString();
			}
		} catch (System::Exception^ err) {
			System::Console::Error->WriteLine("ParseXMLFile System::Exception : " + err->Message);
			throw err;
		}

		return nullptr;
	}

	void CliWrapperXip::ParseXMLFileToFile(System::String^ file, int grmHandler, int depth) {
			CliWrapperXip::ParseXMLFileToFile(file, grmHandler, depth, XML_NONE);
	}

	void CliWrapperXip::ParseXMLFileToFile(System::String^ file, int grmHandler, int depth, char xmloutput) {
		try {
			//std::string outExt(".out");
			StringUtilities::StringConvertor sc1(file);
			StringUtilities::StringConvertor out(file + ".out");
			//std::string outFile = sc1.STLAnsiString + outExt;

			//std::ofstream ofs(outFile.c_str());
			std::ofstream ofs(out.STLAnsiString.c_str());
			//System::Console::Error->WriteLine("before XipParseFileXMLToFile");
			int res = XipParseFileXMLToFile(sc1.STLAnsiString.c_str(), grmHandler, &ofs, depth, xmloutput);
			//System::Console::Error->WriteLine("after XipParseFileXMLToFile " + res);
			if (res == 0) {
				//System::Console::Error->WriteLine("out.STLAnsiString " + out.ToString());
				std::ifstream fichier(out.STLAnsiString.c_str());
				std::stringstream buffer;
				buffer << fichier.rdbuf();

				StringUtilities::StringConvertor scb(buffer.str());

				//System::Console::Error->WriteLine("scb.ToString() " + scb.ToString());
				//return scb.ToString();
			}
		} catch (System::Exception^ err) {
			System::Console::Error->WriteLine("ParseXMLFileToFile System::Exception : " + err->Message);
			throw err;
		}
	}

	void CliWrapperXip::CleanCurrentXipResult(unsigned int grmHandler) {
		try {
			XipCleanCurrentXipResult(grmHandler);
		} catch (System::Exception^ err) {
			System::Console::Error->WriteLine("CleanCurrentXipResult System::Exception : " + err->Message);
			throw err;
		}
	}

	int CliWrapperXip::LicenseExpiringIn(int grmHandler) {
		try {
			return XipLicense(grmHandler);
		}
		catch (System::Exception^ err) {
			System::Console::Error->WriteLine("LicenseExpiringIn System::Exception : " + err->Message);
			throw err;
		}

		return -1;
	}

	int CliWrapperXip::ParameterFile(int grmHandler, System::String^ filename) {
		try {
			StringUtilities::StringConvertor sc1(filename);

			return XipParameterFile(grmHandler, sc1.STLAnsiString.c_str());
		}
		catch (System::Exception^ err) {
			System::Console::Error->WriteLine("ParameterFile System::Exception : " + err->Message);
			throw err;
		}

		return -1;
	}

	int CliWrapperXip::ExistGrammar(int grmHandler) {
		try {
			return XipExistGrammar(grmHandler);
		}
		catch (System::Exception^ err) {
			System::Console::Error->WriteLine("ExistGrammar System::Exception : " + err->Message);
			throw err;
		}

		return -1;
	}


	void CliWrapperXip::FreeGrammar(unsigned int grmHandler) {
		try {
			XipFreeGrammar(grmHandler);
		}
		catch (System::Exception^ err) {
			System::Console::Error->WriteLine("FreeGrammar System::Exception : " + err->Message);
			throw err;
		}
	}

	// Variables related methods
	void CliWrapperXip::SetDisplayMode(int grmHandler, unsigned long mode) {
		try {
			XipSetDisplayMode(grmHandler, mode);
		}
		catch (System::Exception^ err) {
			System::Console::Error->WriteLine("SetDisplayMode System::Exception : " + err->Message);
			throw err;
		}
	}

	void CliWrapperXip::AddFlagDisplayMode(int grmHandler, unsigned long mode) {
		try {
			XipAddFlagDisplayMode(grmHandler, mode);
		}
		catch (System::Exception^ err) {
			System::Console::Error->WriteLine("AddFlagDisplayMode System::Exception : " + err->Message);
			throw err;
		}
	}

	void CliWrapperXip::RemoveFlagDisplayMode(int grmHandler, unsigned long mode) {
		try {
			XipRemoveFlagDisplayMode(grmHandler, mode);
		}
		catch (System::Exception^ err) {
			System::Console::Error->WriteLine("RemoveFlagDisplayMode System::Exception : " + err->Message);
			throw err;
		}
	}

	System::String^ CliWrapperXip::TestFlagDisplayMode(int grmHandler, unsigned long mode) {
		try {
			char res = XipTestFlagDisplayMode(grmHandler, mode);		
			StringUtilities::StringConvertor sc1(&res);

			return sc1.ToString();
		}
		catch (System::Exception^ err) {
			System::Console::Error->WriteLine("TestFlagDisplayMode System::Exception : " + err->Message);
			throw err;
		}

		return nullptr;
	}

	System::String^ CliWrapperXip::SetVariable(int grmHandler, System::String^ variable, float value) {
		try {
			StringUtilities::StringConvertor sc1(variable);

			char res = XipSetVariable(grmHandler, sc1.STLAnsiString.c_str(), value);
			StringUtilities::StringConvertor sc2(&res);

			return sc2.ToString();
		}
		catch (System::Exception^ err) {
			System::Console::Error->WriteLine("SetVariable System::Exception : " + err->Message);
			throw err;
		}

		return nullptr;
	}

	System::String^ CliWrapperXip::SetStringVariable(int grmHandler, System::String^ variable, System::String^ value) {
		try {
			StringUtilities::StringConvertor sc1(variable);
			StringUtilities::StringConvertor sc2(value);

			char res = XipSetStringVariable(grmHandler, sc1.STLAnsiString.c_str(), sc2.STLAnsiString.c_str());
			StringUtilities::StringConvertor sc3(&res);

			return sc3.ToString();
		}
		catch (System::Exception^ err) {
			System::Console::Error->WriteLine("SetStringVariable System::Exception : " + err->Message);
			throw err;
		}

		return nullptr;
	}

	System::String^ CliWrapperXip::AddStringVariable(int grmHandler, System::String^ string_vector, System::String^ value) {
		try {
			StringUtilities::StringConvertor sc1(string_vector);
			StringUtilities::StringConvertor sc2(value);

			char res = XipAddStringVariable(grmHandler, sc1.STLAnsiString.c_str(), sc2.STLAnsiString.c_str());
			StringUtilities::StringConvertor sc3(&res);

			return sc3.ToString();
		}
		catch (System::Exception^ err) {
			System::Console::Error->WriteLine("AddStringVariable System::Exception : " + err->Message);
			throw err;
		}

		return nullptr;
	}

	System::String^ CliWrapperXip::SetIntVariable(int grmHandler, System::String^ variable, float value) {
		try {
			StringUtilities::StringConvertor sc1(variable);

			char res = XipSetIntVariable(grmHandler, sc1.STLAnsiString.c_str(), value);
			StringUtilities::StringConvertor sc2(&res);

			return sc2.ToString();
		}
		catch (System::Exception^ err) {
			System::Console::Error->WriteLine("SetIntVariable System::Exception : " + err->Message);
			throw err;
		}

		return nullptr;
	}

	System::String^ CliWrapperXip::AddIntVariable(int grmHandler, System::String^ string_vector, float value) {
		try {
			StringUtilities::StringConvertor sc1(string_vector);

			char res = XipAddIntVariable(grmHandler, sc1.STLAnsiString.c_str(), value);
			StringUtilities::StringConvertor sc2(&res);

			return sc2.ToString();
		}
		catch (System::Exception^ err) {
			System::Console::Error->WriteLine("AddIntVariable System::Exception : " + err->Message);
			throw err;
		}

		return nullptr;
	}

	System::String^ CliWrapperXip::ClearVariable(int grmHandler, System::String^ string_vector) {
		try {
			StringUtilities::StringConvertor sc1(string_vector);

			char res = XipClearVariable(grmHandler, sc1.STLAnsiString.c_str());
			StringUtilities::StringConvertor sc2(&res);

			return sc2.ToString();
		}
		catch (System::Exception^ err) {
			System::Console::Error->WriteLine("ClearVariable System::Exception : " + err->Message);
			throw err;
		}

		return nullptr;
	}

	System::String^ CliWrapperXip::ClearIntVariable(int grmHandler, System::String^ string_vector) {
		try {
			StringUtilities::StringConvertor sc1(string_vector);

			char res = XipClearIntVariable(grmHandler, sc1.STLAnsiString.c_str());
			StringUtilities::StringConvertor sc2(&res);

			return sc2.ToString();
		}
		catch (System::Exception^ err) {
			System::Console::Error->WriteLine("ClearIntVariable System::Exception : " + err->Message);
			throw err;
		}

		return nullptr;
	}
};
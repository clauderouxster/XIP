using System;
using System.Text;
using System.IO;
using cliWrapper;
using NUnit.Framework;
using log4net;

namespace CSharpClient
{

    [TestFixture] public class test
	{
        private static readonly ILog logger = LogManager.GetLogger(typeof(test)); 
        
        private static sbyte XML_NONE = 0;
		//private static sbyte XML_OUTPUT = 1;
		//private static sbyte XML_INSERT = 2;

		private static uint DISPLAY_NONE = 16384;
        CliWrapperXip cp = null;
        int grmHandler = -1;

        static void Main(string[] args)
        {
            log4net.Config.XmlConfigurator.Configure();
            if (args.Length < 1)
            {
                logger.Error("Wrong number of arguments submitted" + Environment.NewLine);
                Usage();
                return;
            }

            // processing a variable number of arguments as a key-value pair
            logger.Info(Environment.NewLine + "XIP C# .Net Command Line Tool" + Environment.NewLine);

            // create variables to hold arguments
            string effectedSystem = "";
            string systemStatus = "";

            string inf = null;
            string grm = null;

            // populate the variables from the arguments, since we have key-value 
            // pairs passed in, we skip through them by twos
            for (int i = 0; i < args.Length; i += 2)
            {
                try
                {
                    effectedSystem = args[i].ToString();    // first arg-the key
                    systemStatus = args[i + 1].ToString();   // second arg-the value
                    //outputFormatLevel = args[i + 2].ToString();   // second arg-the value
                }
                catch
                {
                    // if an incorrect number of items were listed, show the
                    // correctly populated items and then exit out after a pause
                    //Console.ReadLine();
                    logger.Error("An error occured reading the arguments. Please refer to the usage below." + Environment.NewLine);
                    Usage();
                    Environment.Exit(-1);
                }

                // sets the system and displays the message
                switch (effectedSystem)
                {
                    case "-if":
                        //logger.Info("Input File " + systemStatus.ToString());
                        if (inf == null)
                            inf = systemStatus.ToString();
                        else
                        {
                            TextWriter errorWriter = Console.Error;
                            errorWriter.WriteLine("Can only specify one input file at a time");
                            Environment.Exit(-1);
                        }

                        inf = Path.GetFullPath(inf);
                        if (!File.Exists(inf))
                        {
                            TextWriter errorWriter = Console.Error;
                            errorWriter.WriteLine("Error accessing the input file : " + inf);
                            Environment.Exit(-1);
                        }
                        break;
                    case "-grm":
                        //logger.Info("Input File " + systemStatus.ToString());
                        if (grm == null)
                            grm = systemStatus.ToString();
                        else
                        {
                            TextWriter errorWriter = Console.Error;
                            errorWriter.WriteLine("Can only specify one grm file");
                            Environment.Exit(-1);
                        }

                        grm = Path.GetFullPath(grm);
                        if (!File.Exists(grm))
                        {
                            TextWriter errorWriter = Console.Error;
                            errorWriter.WriteLine("Error accessing the grm file : " + grm);
                            Environment.Exit(-1);
                        }
                        break;
                    default:
                        logger.Error("Wrong argument submitted : " + effectedSystem + Environment.NewLine);
                        Usage();
                        Environment.Exit(-1);
                        break;
                }
            }

            if (inf != null && grm != null)
            {
                logger.Info("before Process " + grm + ", " + inf);
                Process(grm, inf);
            }
            else
            {
                logger.Error("Wrong argument submitted" + Environment.NewLine);
                Usage();
                Environment.Exit(-1);
            }
        }
        
        private static void Usage()
        {
            logger.Info("Usage: " + Environment.NewLine +
                    "   NuanceCommandLine.exe " + Environment.NewLine +
                    "     -grm GRM_FILE_PATH" + Environment.NewLine +
                    "     -if INPUT_FILE_PATH" + Environment.NewLine
                    );
        }

		static void Process(string grm_, string file_)
		{
            try
            {
                logger.Info("Starting ...");
                DateTime startTime1 = DateTime.Now;

                CliWrapperXip cp_ = new CliWrapperXip();
                string grmFilePath = grm_;
                logger.Info("C# LoadGrammar " + grmFilePath);
                int grm = cp_.LoadGrammar(grmFilePath);
                logger.Info("Grammar handler : " + grm);
                DateTime stopTime1 = DateTime.Now;
                TimeSpan duration1 = stopTime1 - startTime1;
                logger.Info("=== C# LoadGrammar took : " + duration1.TotalMilliseconds + " milliseconds.\n");

                //uint displayMode = 0;
                //cp_.SetDisplayMode(grm, displayMode);
                //cp_.AddFlagDisplayMode(grm, DISPLAY_NONE); 

                //DateTime startTime2 = DateTime.Now;
                //logger.Info("C# ParseXMLString");
                //logger.Info(cp_.ParseXMLString(
                //    "<?xml version=\"1.0\"?><document>La petite fille joue dans la coure avec la balle bleue.</document>", 
                //    grm, 0));
                DateTime startTime3 = DateTime.Now;
                //TimeSpan duration2 = startTime3 - startTime2;
                //logger.Info("=== C# ParseXMLString took : " + duration2.TotalMilliseconds + " milliseconds.\n");

                DateTime startTime4 = DateTime.Now;
                TimeSpan duration3 = System.TimeSpan.FromSeconds(0);
                DateTime startTime5 = DateTime.Now;
                TimeSpan duration4 = System.TimeSpan.FromSeconds(0);

                if (File.Exists("..\\..\\..\\..\\test\\resources\\test.txt"))
                {
                    logger.Info("C# ParseFile");
                    logger.Info(cp_.ParseFile("..\\..\\..\\..\\test\\resources\\test.txt", grm));
                    startTime4 = DateTime.Now;
                    duration3 = startTime4 - startTime3;
                    logger.Info("=== C# ParseFile took : " + duration3.TotalMilliseconds + " milliseconds.\n");

                    logger.Info("C# ParseFileToFile");
                    cp_.ParseFileToFile("..\\..\\..\\..\\test\\resources\\test.txt", grm);
                    startTime5 = DateTime.Now;
                    duration4 = startTime5 - startTime4;
                    logger.Info("=== C# ParseFileToFile took : " + duration4.TotalMilliseconds + " milliseconds.\n");
                }
                else
                    logger.Warn("Could not test ParseFile and ParseFileToFile methods\n");

                logger.Info("C# ParseXMLFile");
                logger.Info(cp_.ParseXMLFile(file_, grm, 0, XML_NONE));
                DateTime stopTime5 = DateTime.Now;
                TimeSpan duration5 = stopTime5 - startTime5;
                logger.Info("=== C# ParseXMLFile took : " + duration5.TotalMilliseconds + " milliseconds.\n");

                // Compute the total execution time.
                TimeSpan totalDuration = duration1 + duration3 + duration4 + duration5;
                logger.Info("\n\n==================== Total duration: " + totalDuration.TotalMilliseconds + " milliseconds.\n");

                //logger.Info("C# FreeGrammar");
                cp_.FreeGrammar((uint)grm);
            }
            catch (Exception e)
            {
                logger.Error("Process Exception : " + e.Message);
            }
		}

        [Test]
        public void testParseXMLFile()
        {
            DateTime startTime = DateTime.Now;
            logger.Info("C# ParseXMLFile");

            //uint displayMode = 0;
            //cp.SetDisplayMode(grmHandler, displayMode);
            cp.AddFlagDisplayMode(grmHandler, DISPLAY_NONE); 
            
            logger.Info(cp.ParseXMLFile("..\\..\\..\\test\\resources\\test.xml", grmHandler, 0, XML_NONE));

            DateTime stopTime = DateTime.Now;
            TimeSpan duration = stopTime - startTime;
            logger.Info("=== C# ParseXMLFile took : " + duration.TotalMilliseconds + " milliseconds.\n");
        }

        [Test]
        public void testParseString()
        {
            DateTime startTime = DateTime.Now;
            logger.Info("C# ParseString");
            logger.Info(cp.ParseString("La petite fille joue dans la coure avec la balle bleue.", grmHandler));

            DateTime stopTime = DateTime.Now;
            TimeSpan duration = stopTime - startTime;
            logger.Info("=== C# ParseString took : " + duration.TotalMilliseconds + " milliseconds.\n");
        }

        [Test]
        public void testParseFile()
        {
            DateTime startTime = DateTime.Now;
            logger.Info("C# ParseFile");
            logger.Info(cp.ParseFile("..\\..\\..\\test\\resources\\test.txt", grmHandler));

            DateTime stopTime = DateTime.Now;
            TimeSpan duration = stopTime - startTime;
            logger.Info("=== C# ParseFile took : " + duration.TotalMilliseconds + " milliseconds.\n");
        }

        [Test]
        public void ParseFileToFile()
        {
            DateTime startTime = DateTime.Now;
            logger.Info("C# ParseFileToFile");
            cp.ParseFileToFile("..\\..\\..\\test\\resources\\test.txt", grmHandler);

            DateTime stopTime = DateTime.Now;
            TimeSpan duration = stopTime - startTime;
            logger.Info("=== C# ParseFileToFile took : " + duration.TotalMilliseconds + " milliseconds.\n");
        }

        [TestFixtureSetUp]
        public void DoTestSuiteSetUp()
        {
            DateTime startTime = DateTime.Now;
            logger.Info("TestCaseSetup");
            cp = new CliWrapperXip();
            string grmFilePath = "..\\..\\..\\resources\\bouygues_french.grm";
            logger.Info("C# LoadGrammar");
            grmHandler = cp.LoadGrammar(grmFilePath);
            logger.Info("Grammar handler : " + grmHandler);
            DateTime stopTime = DateTime.Now;
            TimeSpan duration = stopTime - startTime;
            logger.Info("=== C# LoadGrammar took : " + duration.TotalMilliseconds + " milliseconds.\n");
        }

        [TestFixtureTearDown]
        public void DoTestSuiteTearDown()
        {
            logger.Info("TestSuiteTearDown");
            cp.FreeGrammar((uint)grmHandler);
        }

        [TearDown]
        public void DoTestCaseTearDown()
        {
            logger.Info("TestCaseTearDown");
        }

        [SetUp]
        public void DoTestCaseSetup()
        {
            
        }
    }
}
#include "ManagedXipResult.h"
#include "xipstlres.h"
#include <windows.h>
#include <vcclr.h>
#include "utils.h"

namespace cliWrapper {
	
	ManagedXipResult::ManagedXipResult()
	{
		pXipResult = new XipResult();
		if (!pXipResult)
		{
			throw new System::Exception("Cannot create a XipResult");
		}
	}

	void ManagedXipResult::print(char feature)
	{
		//char someValue = feature;
		//char __pin* pinnedChar = &someValue;
		//pXipResult->print(&pinnedChar);
		pXipResult->print(feature);
	}

	void ManagedXipResult::printbare(char feature)
	{
		//char someValue = feature;
		//char __pin* pinnedChar = &someValue;
		//pXipResult->printbare(pinnedChar);
		pXipResult->printbare(feature);
	}

	ManagedXipResult::~ManagedXipResult()
	{
		if (pXipResult)
			delete pXipResult;
	}
};
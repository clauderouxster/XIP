// ManagedWrapper.cpp

// This code verifies that DllMain is not automatically called 
// by the Loader when linked with /noentry. It also checks some
// functions that the CRT initializes.

#include "_vcclrit.h"


public __gc class ManagedWrapper {
public:
	static BOOL minitialize();
	static BOOL mterminate();
};

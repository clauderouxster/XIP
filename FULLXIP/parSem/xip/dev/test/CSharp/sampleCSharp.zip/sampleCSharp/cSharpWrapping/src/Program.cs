using System;
using System.Text;
using cliWrapper;

namespace CSharpClient
{

	class Program
	{
		private static sbyte XML_NONE = 0;
		private static sbyte XXML_OUTPUT = 1;
		private static sbyte XXML_INSERT = 2;

		private static uint DISPLAY_NONE = 16384;

		static void Main(string[] args)
		{
            System.Console.WriteLine("Starting ...");
			/* Read the initial time. */
			DateTime startTime1 = DateTime.Now;

			/* Do something that takes up some time. For example sleep for 1.7 seconds. */
			CliWrapperXip cp = new CliWrapperXip();
			string grmFilePath = "C:\\Projects\\XIP\\src\\cpp\\VS2005\\CSharpClient\\sample.grm";
			//"C:\\Documents and Settings\\niemaz\\My Documents\\Visual Studio Projects\\interoperabilite\\CliWrapping\\xipWrapping\\CSharpClient\\grammar\\english\\entity\\gram_gen_entit.grm";
			System.Console.WriteLine("C# LoadGrammar");
			int grm = cp.LoadGrammar(grmFilePath);

			uint displayMode = 0;
			cp.SetDisplayMode(grm, displayMode);
			cp.AddFlagDisplayMode(grm, DISPLAY_NONE);

			/* Read the end time. */
			DateTime stopTime1 = DateTime.Now;

			/* Compute and print the duration of this first task. */
			TimeSpan duration1 = stopTime1 - startTime1;
			Console.WriteLine("C# LoadGrammar took : {0} milliseconds.", duration1.TotalMilliseconds);

			/* Now we want to measure another task. We store the start time. */
			DateTime startTime2 = DateTime.Now;

			/* We perform the second task which again takes up some time.
			 * For example we can sleep for 2.1 seconds. */
			System.Console.WriteLine("C# ParseString");
			System.Console.WriteLine(cp.ParseString("Bonjour petite fleur", grm, XML_NONE));

			/* We store the end time of the second task. */
			DateTime stopTime2 = DateTime.Now;

			/* Compute and print the duration of this second task. */
			TimeSpan duration2 = stopTime2 - startTime2;
			Console.WriteLine("C# ParseString took : {0} milliseconds.", duration2.TotalMilliseconds);

			DateTime startTime3 = DateTime.Now;
			System.Console.WriteLine("C# ParseFileToFile");
            System.Console.WriteLine(cp.ParseFileToFile("C:\\Projects\\XIP\\src\\cpp\\VS2005\\CSharpClient\\test.txt", grm, XML_NONE));
			DateTime stopTime3 = DateTime.Now;
			TimeSpan duration3 = stopTime3 - startTime3;
			Console.WriteLine("C# ParseFileToFile took : {0} milliseconds.", duration3.TotalMilliseconds);

			DateTime startTime4 = DateTime.Now;
			System.Console.WriteLine("C# ParseFile");
            System.Console.WriteLine(cp.ParseFile("C:\\Projects\\XIP\\src\\cpp\\VS2005\\CSharpClient\\test.txt", grm, XML_NONE));
			DateTime stopTime4 = DateTime.Now;
			TimeSpan duration4 = stopTime4 - startTime4;
			Console.WriteLine("C# ParseFile took : {0} milliseconds.", duration4.TotalMilliseconds);


			DateTime startTime5 = DateTime.Now;
			System.Console.WriteLine("C# ParseXMLFile");
            System.Console.WriteLine(cp.ParseXMLFile("C:\\Projects\\XIP\\src\\cpp\\VS2005\\CSharpClient\\test.xml", grm, 0, XML_NONE));
            System.Console.WriteLine(cp.ParseXMLFile("C:\\Projects\\XIP\\src\\cpp\\VS2005\\CSharpClient\\test0.xml", grm, 0, XML_NONE));
            DateTime stopTime5 = DateTime.Now;
			TimeSpan duration5 = stopTime5 - startTime5;
			Console.WriteLine("C# ParseXMLFile took : {0} milliseconds.", duration5.TotalMilliseconds);
			
			/* Compute the total execution time. */
			TimeSpan totalDuration = duration1 + duration2 + duration3 + duration4 + duration5;
			Console.WriteLine("Total duration: {0} milliseconds.", totalDuration.TotalMilliseconds);
			

			//System.Console.WriteLine("C# FreeGrammar");
			//cp.FreeGrammar(grm);
		}
	}
}

#include <string>

#using <mscorlib.dll>

	//Converts a System::String to a std::string
	//void ManagedToSTL(System::String^ managed, std::string *outstr);
		
	//Converts a std::string to a System::String
	//System::String^ STLToManaged(std::string stl);

	//System::String^ To_String( const std::string& input );

	//bool To_CharStar( System::String^ source, char*& target );

	//bool To_string( System::String^ source, std::string &target );

//#endif
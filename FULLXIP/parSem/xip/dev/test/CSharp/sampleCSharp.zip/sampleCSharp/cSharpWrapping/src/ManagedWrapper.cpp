// ManagedWrapper.cpp

// This code verifies that DllMain is not called by the Loader
// automatically when linked with /noentry. It also checks some
// functions that the CRT initializes.

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#include "utils.h"
#include <_vcclrit.h>


using namespace System;

public __gc class ManagedWrapper {
public:
   static int minitialize() {
      int retval = 0;
      try {
            __crt_dll_initialize();
      } catch(System::Exception* e) {
         Console::WriteLine(e);
         retval = 1;
      }
      return retval;
   }
   static int mterminate() {
      int retval = 0;
      try {
            __crt_dll_terminate();
      } catch(System::Exception* e) {
         Console::WriteLine(e);
         retval = 1;
      }
      return retval;
   }
};

BOOL WINAPI DllMain(HINSTANCE hModule, DWORD dwReason, LPVOID lpvReserved) {
   Console::WriteLine(S"DllMain is called...");
   return TRUE;
} /* DllMain */
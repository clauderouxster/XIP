//#include <string>

//using std::string;
#include "utils.h"
#include <stdlib.h>
#include <vcclr.h>

//Converts a System::String to a std::string
//void ManagedToSTL(System::String^ managed, std::string *outstr) {
	//get a pointer to an array of ANSI chars and assign it to a string
	//char *chars = (char*) System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(managed).ToPointer();
	//(*outstr) = chars;

	//free the memory used by the array
	//since the array is not managed, it will not be claimed by the garbage collector
	//System::Runtime::InteropServices::Marshal::FreeHGlobal(chars);
//}

//Converts a std::string to a System::String
//System::String^ STLToManaged(std::string stl) {
	//the c_str() function gets a char array from the STL string,
	//but the PtrToStringAnsi function wants a int array, so it gets casted
	//return  System::Runtime::InteropServices::Marshal::PtrToStringAnsi((int*) stl.c_str());
//}

/*bool To_CharStar( System::String^ source, char*& target ) {

	int len = (( source->Length+1) * 2);

	target = new char[ len ];

	pin_ptr<const wchar_t> wch = PtrToStringChars( source );

	return wcstombs( target, wch, len ) != -1;

}



bool To_string( System::String^ source, std::string &target ) {

	int len = (( source->Length+1) * 2);

	char *ch = new char[ len ];

	bool result ;

	{

		pin_ptr<const wchar_t> wch = PtrToStringChars( source );

		result = wcstombs( ch, wch, len ) != -1;

	}

	target = ch;

	delete[] ch;

	return result;

}
*
/
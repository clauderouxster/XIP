// cliWrapper.h

#pragma once

#define XIPDLL_EXPORT
#define XIPLIBXML

#include "xipstlres.h"

#include <windows.h>
#include <vcclr.h>

using namespace System;

namespace cliWrapper {

	public ref class CliWrapperXip
	{
		// TODO: Add your methods for this class here.
        private:
			//	CliWrapperXip(){};       // default constructor forbidden
			//CMerde^  cp;
			//std::ostringstream __nogc* os;

        public:
			CliWrapperXip();

            ~CliWrapperXip();
			!CliWrapperXip();

			// loading grammar
			int LoadGrammar(System::String^ grmfile);
			int LoadGrammar(System::String^ grmfile, char loadAll);
			int LoadGrammar(System::String^ grmfile, char loadAll, int xml);
	
			// parsing text
			System::String^ ParseString(System::String^ text, int grmHandler);
			System::String^ ParseString(System::String^ text, int grmHandler, char xmloutput);
			System::String^ ParseFile(System::String^ file, int grmHandler);
			System::String^ ParseFile(System::String^ file, int grmHandler, char xmloutput);
			void ParseFileToFile(System::String^ file, int grmHandler);
			void ParseFileToFile(System::String^ file, int grmHandler, char xmloutput);
			System::String^ ParseXMLString(System::String^ text, int grmHandler, int depth);
			System::String^ ParseXMLString(System::String^ text, int grmHandler, int depth, char xmloutput);
			System::String^ ParseXMLFile(System::String^ file, int grmHandler, int depth);
			System::String^ ParseXMLFile(System::String^ file, int grmHandler, int depth, char xmloutput);
			void ParseXMLFileToFile(System::String^ file, int grmHandler, int depth);
			void ParseXMLFileToFile(System::String^ file, int grmHandler, int depth, char xmloutput);
			
			void CleanCurrentXipResult(unsigned int grmHandler);
			int LicenseExpiringIn(int grmHandler);
			int ParameterFile(int grmHandler, System::String^ filename);
			int ExistGrammar(int grmHandler);
			void FreeGrammar(unsigned int grmHandler);
			void SetDisplayMode(int grmHandler, unsigned long mode);
			void AddFlagDisplayMode(int grmHandler, unsigned long mode);
			void RemoveFlagDisplayMode(int grmHandler, unsigned long mode);
			System::String^ TestFlagDisplayMode(int grmHandler, unsigned long mode);
			System::String^ SetVariable(int grmHandler, System::String^ variable, float value);
			System::String^ SetStringVariable(int grmHandler, System::String^ variable, System::String^ value);
			System::String^ AddStringVariable(int grmHandler, System::String^ string_vector, System::String^ value);
			System::String^ SetIntVariable(int grmHandler, System::String^ variable, float value);
			System::String^ AddIntVariable(int grmHandler, System::String^ string_vector, float value);
			System::String^ ClearVariable(int grmHandler, System::String^ string_vector);
			System::String^ ClearIntVariable(int grmHandler, System::String^ string_vector);



	};
} // namespace cliWrapper
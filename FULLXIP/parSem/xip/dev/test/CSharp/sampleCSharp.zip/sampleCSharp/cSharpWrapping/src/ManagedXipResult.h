// cliWrapper.h

#pragma once

#include "xipstlres.h"
#include <windows.h>
#include <vcclr.h>

using namespace System;

namespace cliWrapper {

	public __gc class ManagedXipResult
	{
		// TODO: Add your methods for this class here.
        //protected:
		//	ManagedXipResult(){};       // default constructor forbidden
			

        public:
			ManagedXipResult();
			XipResult * pXipResult;
            virtual  ~ManagedXipResult();

			void print(char feature);
			void printbare(char feature);
	};
} // namespace cliWrapper